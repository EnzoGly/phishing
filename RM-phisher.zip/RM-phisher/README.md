# RM-phisher

<p align="center">A beginners friendly, Automated phishing tool with 30+ templates.</p>

##

<h3><p align="center">Disclaimer</p></h3>

<i>Any actions and or activities related to <b>RM-phisher</b> is solely your responsibility. The misuse of this toolkit can result in <b>criminal charges</b> brought against the persons in question. <b>The contributors will not be held responsible</b> in the event any criminal charges be brought against any individuals misusing this toolkit to break the law.

<b>This toolkit contains materials that can be potentially damaging or dangerous for social media</b>. Refer to the laws in your province/country before accessing, using,or in any other way utilizing this in a wrong way.

<b>This Tool is made for educational purposes only!</b>. Do not attempt to violate the law with anything contained here. <b>If this is your intention, then Get the hell out of here</b>!

It only demonstrates "how phishing works". <b>You shall not misuse the information to gain unauthorized access to someones social media</b>. However you may try out this at your own risk. LOL</i>

##



### Features

- Latest and updated login pages.
- Masked URL support - [http only] 
- Beginners friendly
- Tunneling options
  - Localhost (visit 127.0.0.1:8080)
  - Cloudflare (default, automated and undetected)

### Screenshots 
#### Menu
![Screenshot_20220413-100117_Kali](https://i.imgur.com/p2pi0yk.jpg?1)
#### Website and login page selection
![Screenshot_20220413-101720_Kali](https://i.imgur.com/rnbpnY7.jpg?1)
#### Share the link and grab details
![Screenshot_20220413-102024_Kali](https://i.imgur.com/NFGsvn3.jpg)



### Installation

#### Just, Clone this repository -
```
git clone git://github.com/ritheshnayak/RM-phisher.git
```

#### Change to cloned directory -
```
cd RM-phisher
```

#### Follow the Commands here
```
chmod 777 RM-phisher.sh
```
```
sudo bash RM-phisher.sh
```
- ### Dependencies

**`RM-phisher`** requires following programs to run properly [installed automatically]- 
- `php`
- `wget`
- `curl`
- `git`

>
> All the dependencies will be installed automatically when you run `Rm-phisher` for the first time.
>
> Supported Platform : **`Termux[on android]`**, **`Ubuntu/Debian/Kali/Parrot`**, **`Arch Linux/Manjaro`**, **`Fedora`**
>
